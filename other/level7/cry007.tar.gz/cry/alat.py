#!/usr/bin/python2
import hashlib, string, sys

ROUNDS = 20000

def xor(a, b):
    l = min(len(a), len(b))
    return ''.join([chr(ord(x) ^ ord(y)) for x, y in zip(a[:l], b[:l])])

def h(x):
    x = hashlib.sha256(x).digest()
    x = xor(x[:16], x[16:])
    return x

def verify(x):
    return all([ord(c) < 127 for c in x])

def crypt(msg, passwd):
    k = h(passwd)

    for i in xrange(ROUNDS):
        k = h(k)

    out = ''
    for i in xrange(0, len(msg), 16):
        out += xor(msg[i:i+16], k)
        k = h(k + str(len(msg)))

    return out

def enkrip(msg, passwd):
    msg = crypt(msg, passwd)

    return msg.encode('base64')

def dekrip(msg, passwd):
    msg = crypt(msg.decode('base64'), passwd)

    if verify(msg):
        return msg
    else:
        sys.stderr.write('Sok tau !\n')
        sys.exit(1)

if len(sys.argv) < 5 or sys.argv[1] not in ('enkrip', 'dekrip'):
    print 'Usage:\talat.py enkrip <password> <pesan> <hasil>'
    print '\talat.py dekrip <password> <pesan> <hasil>'
    sys.exit(1)

op, passwd, pesan, hasil = sys.argv[1:]

inp = open(pesan).read()

if op == 'enkrip':
    ct = enkrip(inp, passwd)
    open(hasil, 'w').write(ct)
elif op == 'dekrip':
    pt = dekrip(inp, passwd)
    open(hasil, 'w').write(pt)
